---
files:
  - https://projects.fivethirtyeight.com/nfl-api/nfl_elo.csv
---
# NFL Elo

This file contains links to the data behind [The Complete History Of The NFL](https://projects.fivethirtyeight.com/complete-history-of-the-nfl/) and our [NFL Predictions](https://projects.fivethirtyeight.com/2017-nfl-predictions/).

`nfl_elo.csv` contains game-by-game Elo ratings and forecasts back to 1920.
